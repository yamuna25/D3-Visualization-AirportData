1. Install the localserver extension for chrome using following link
https://chrome.google.com/webstore/detail/web-server-for-chrome/ofhbbkphhbklhfoeikjpcbhemlocgigb?hl=en
2. Download Project.zip file and unzip it
3. Select the folder Code in the installed webserver
4. Run index.html file
5. Click each link in the page